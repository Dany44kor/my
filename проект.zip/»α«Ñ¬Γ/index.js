var loginn;
var password;

let saved_login = null;
//console.log(localStorage.getItem('number'))


function login(){
    loginn = document.getElementById('login').value;
    password = document.getElementById('password').value;

    console.log(loginn)

    fetch("http://localhost:3000/user?id=" + loginn)
    .then(res => res.json())
    .then(data => {
        if (data.length == 0){
            console.log('Такого аккаунта нет')
        }
        data.forEach(user => {
            if (user.id == loginn && user.password == password){
                console.log('complete')
                saved_login = document.getElementById('login').value;
                localStorage.setItem('saved_login', saved_login.toString())
                window.location.replace("account.html");
            } else{
                console.log('wrong password')
            }
        })
    })
}

function register(){
    loginn = document.getElementById('login').value;
    password = document.getElementById('password').value;
    
    fetch("http://localhost:3000/user?id=" + loginn)
    .then(res => res.json())
    .then(data => {
        if (data.length != 0){
            console.log('Такой аккаунт уже есть!')
            return false;
        } else{
            fetch("http://localhost:3000/user", {
                method: 'POST',
                headers: {
                    "Content-type": "application/json"
                },
                body: JSON.stringify({
                    "id": loginn,
                    "password": password
                })
            })
            .then(res => res.json())
            .then(data => {
                console.log('complete')
                saved_login = document.getElementById('login').value;
                localStorage.setItem('saved_login', saved_login.toString())
                window.location.replace("account.html");
            })
        }
    })

}

function add(){
    fetch("http://localhost:3000/posts/", {
        method: 'POST',
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify({
            "user": localStorage.getItem('saved_login'),
            "name": document.getElementById('name').value,
            "specification": document.getElementById('specification').value,
            "platform": document.getElementById('platform').value,
            "buyer": document.getElementById('buyer').value,
            "status": document.getElementById('status').value,
            "data": document.getElementById('data').value,
            "price": document.getElementById('price').value,
        })
    })
    .then(res => res.json())
    .then(data => console.log(data))
}


function account(){
    console.log(localStorage.getItem('saved_login'))
    document.getElementById('account').innerHTML = localStorage.getItem('saved_login');
}

function logout(){
    saved_login = null;
    localStorage.removeItem('saved_login')
    window.location.replace("login.html");
    console.log('Вы вышли')
}


function view(){
    const myKeysValues = window.location.search;
    const urlParams = new URLSearchParams(myKeysValues);
    const id = urlParams.get('id');
    console.log(id)
    fetch("http://localhost:3000/posts?id=" + id)
    .then(res => res.json())
    .then(json => {
        json.map(data =>{
            document.getElementById('name').innerHTML = data.name;
            document.getElementById('specification').innerHTML = data.specification;
            document.getElementById('platform').innerHTML = data.platform;
            document.getElementById('buyer').innerHTML = data.buyer;
            document.getElementById('status').innerHTML = data.status;
            document.getElementById('data').innerHTML = data.data;
            document.getElementById('price').innerHTML = data.price;
        })

    })
}

function w(){
    let tbody = document.getElementById("tbody")
    tbody.append(td_fun());
    fetch("http://localhost:3000/posts?status=В ожидании&user=" + localStorage.getItem('saved_login'))
    .then(res => res.json())
    .then(json => {
        json.map(data =>{
            tbody.append(td_fun(data.name));
        })

    })
}
function td_fun(name){
    let td = document.createElement('tr');
    td.innerHTML = `
    <div>${name}</div>
    `
}
/* function adduser(){
    fetch("http://localhost:3000/posts/" + 1, {
        method: 'PATCH',
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify({
            "children": [
                { "name": "Женя", "age": 5 }
              ]
        })
    })
    .then(res => res.json())
    .then(data => console.log(data))
}*/
